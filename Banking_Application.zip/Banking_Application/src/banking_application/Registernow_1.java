/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking_application;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author JP COMPUTERS
 */
@Entity
@Table(name = "registernow", catalog = "banking", schema = "")
@NamedQueries({
    @NamedQuery(name = "Registernow_1.findAll", query = "SELECT r FROM Registernow_1 r")
    , @NamedQuery(name = "Registernow_1.findByAcctnum", query = "SELECT r FROM Registernow_1 r WHERE r.acctnum = :acctnum")
    , @NamedQuery(name = "Registernow_1.findByName", query = "SELECT r FROM Registernow_1 r WHERE r.name = :name")
    , @NamedQuery(name = "Registernow_1.findByIdnumber", query = "SELECT r FROM Registernow_1 r WHERE r.idnumber = :idnumber")
    , @NamedQuery(name = "Registernow_1.findByPnumber", query = "SELECT r FROM Registernow_1 r WHERE r.pnumber = :pnumber")
    , @NamedQuery(name = "Registernow_1.findByUname", query = "SELECT r FROM Registernow_1 r WHERE r.uname = :uname")
    , @NamedQuery(name = "Registernow_1.findByCpassword", query = "SELECT r FROM Registernow_1 r WHERE r.cpassword = :cpassword")
    , @NamedQuery(name = "Registernow_1.findByAcctbal", query = "SELECT r FROM Registernow_1 r WHERE r.acctbal = :acctbal")})
public class Registernow_1 implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "acctnum")
    private String acctnum;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @Column(name = "idnumber")
    private String idnumber;
    @Basic(optional = false)
    @Column(name = "pnumber")
    private int pnumber;
    @Basic(optional = false)
    @Column(name = "uname")
    private String uname;
    @Basic(optional = false)
    @Column(name = "cpassword")
    private int cpassword;
    @Basic(optional = false)
    @Column(name = "acctbal")
    private String acctbal;

    public Registernow_1() {
    }

    public Registernow_1(String acctnum) {
        this.acctnum = acctnum;
    }

    public Registernow_1(String acctnum, String name, String idnumber, int pnumber, String uname, int cpassword, String acctbal) {
        this.acctnum = acctnum;
        this.name = name;
        this.idnumber = idnumber;
        this.pnumber = pnumber;
        this.uname = uname;
        this.cpassword = cpassword;
        this.acctbal = acctbal;
    }

    public String getAcctnum() {
        return acctnum;
    }

    public void setAcctnum(String acctnum) {
        String oldAcctnum = this.acctnum;
        this.acctnum = acctnum;
        changeSupport.firePropertyChange("acctnum", oldAcctnum, acctnum);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        String oldName = this.name;
        this.name = name;
        changeSupport.firePropertyChange("name", oldName, name);
    }

    public String getIdnumber() {
        return idnumber;
    }

    public void setIdnumber(String idnumber) {
        String oldIdnumber = this.idnumber;
        this.idnumber = idnumber;
        changeSupport.firePropertyChange("idnumber", oldIdnumber, idnumber);
    }

    public int getPnumber() {
        return pnumber;
    }

    public void setPnumber(int pnumber) {
        int oldPnumber = this.pnumber;
        this.pnumber = pnumber;
        changeSupport.firePropertyChange("pnumber", oldPnumber, pnumber);
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        String oldUname = this.uname;
        this.uname = uname;
        changeSupport.firePropertyChange("uname", oldUname, uname);
    }

    public int getCpassword() {
        return cpassword;
    }

    public void setCpassword(int cpassword) {
        int oldCpassword = this.cpassword;
        this.cpassword = cpassword;
        changeSupport.firePropertyChange("cpassword", oldCpassword, cpassword);
    }

    public String getAcctbal() {
        return acctbal;
    }

    public void setAcctbal(String acctbal) {
        String oldAcctbal = this.acctbal;
        this.acctbal = acctbal;
        changeSupport.firePropertyChange("acctbal", oldAcctbal, acctbal);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (acctnum != null ? acctnum.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Registernow_1)) {
            return false;
        }
        Registernow_1 other = (Registernow_1) object;
        if ((this.acctnum == null && other.acctnum != null) || (this.acctnum != null && !this.acctnum.equals(other.acctnum))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "banking_application.Registernow_1[ acctnum=" + acctnum + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
